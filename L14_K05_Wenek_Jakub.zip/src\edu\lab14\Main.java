package edu.lab14;

public class Main {
    public static void main(String[] args) {
        new CMainForm("Kółko-krzyżyk").setVisible(true);
    }
}